# Make and Load Sample Data
# Ryan T. Moore
# First: 2018-09-18
# Last: 2022-01-03

# Set up ------------------------------------------------------------------

library(dplyr)
library(ggplot2)
library(here)

# Make data ---------------------------------------------------------------

n <- 100

x <- sample(50, n, replace = TRUE)
y <- 1 + 2 * x + rnorm(n)

df <- tibble(x, y)

df2 <- tibble(x, y_sq = y ^ 2)


# Save data (where?) ------------------------------------------------------

path_df1 <- here("data", "sim_df.RData")
  
save(df, file = path_df1)

path_df2 <- here("data", "all_dfs", "all_sim_dfs.RData")

save(df, df2, file = path_df2)

# Alternative relative path: 

# save(df, df2, file = "data/all_sim_dfs.RData")

# Quit.  Return by opening .Rproj


# Load later: -------------------------------------------------------------

path_all_dfs <- here("data", "all_dfs", "all_sim_dfs.RData")
 
load(path_all_dfs)


# Make a figure -----------------------------------------------------------

pdf(here("figs", "myplot.pdf"))
ggplot(df2, aes(x, y_sq)) + geom_point() +
  geom_smooth()
dev.off()

# Or, 

# pdf("figs/myplot.pdf")
# ...

